<?php
  echo "<script>
         window.location.replace('user');
       </script>";
  exit;
?>
