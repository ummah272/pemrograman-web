<?php  

include 'functions.php';
$id_driver = $_GET['id_driver'];
$pendapatan = mysqli_query($conn, "SELECT * FROM trans_upn WHERE id_driver = '$id_driver'");

?>


<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
      <title>TransUPN</title>
    <meta name="description" content="" />

    <?php include '../include/link.php' ?>
    <style type="text/css">
      table th, td {
        text-align: center;
      }
      table th {
        font-weight: bold;
      }
    </style>
    
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        
        <!-- SIDEBAR -->
        <?php include '../include/sidebar.php'; ?>

        <!-- Layout container -->
        <div class="layout-page">
          
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
            

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header bg-primary text-white d-flex justify-content-between">Data Detail Driver
                <span class="px-2">
                    <a href="data_pendapatan_driver.php" class="btn btn-dark">Kembali</a>
                  </span>
                </h5>
                <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
                  <table class="table table-hover table-responsive">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama Driver</th>
                        <th>Jumlah KM</th>
                        <th>Tanggal</th>
                        <th>Detail</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php $no = 1; ?>
                      <?php foreach($pendapatan as $td) : ?>
                        <?php 
                          $id_driver = $td['id_driver'];
                          $driver = query("SELECT * FROM driver WHERE id_driver = $id_driver")[0];
                        ?>
                        <tr>
                          <td><?= $no; $no++  ?></td>
                          <td><?= $driver['nama']; ?></td>
                          <td><?= $td['jumlah_km']; ?></td>
                          <td><?= date('d F Y', strtotime($td['tanggal'])); ?></td>
                          <td> <a href="detail_driver.php?id_driver=<?= $td['id_driver'];?>">Lihat</a></td>
                      <?php endforeach; ?>

                      </tbody>
                  </table>
                </div>
              </div>
              <!--/ Basic Bootstrap Table -->
              <hr class="mb-2" />
              
            </div>
            <!-- / Content -->

            
            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->

        
    </div>

    <?php include '../include/js.php'; ?>

  </body>
</html>
