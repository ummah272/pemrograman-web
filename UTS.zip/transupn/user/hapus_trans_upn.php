4<?php
require 'functions.php';
$id = $_GET["id_trans_upn"];
if (hapus_trans_upn($id) > 0 ) {
	echo "
		<script>
			alert('Data berhasil dihapus!');
			document.location.href = 'data_trans_upn.php';
		</script>
	";
    } else {
	echo "
		<script>
			alert('Data gagal dihapus!');
		</script>
	";
	}
 ?>
