4<?php
require 'functions.php';
$id = $_GET["id_driver"];
if (hapus_driver($id) > 0 ) {
	echo "
		<script>
			alert('Data berhasil dihapus!');
			document.location.href = 'data_driver.php';
		</script>
	";
    } else {
	echo "
		<script>
			alert('Data gagal dihapus!');
		</script>
	";
	echo mysqli_error($conn);
	}
 ?>
