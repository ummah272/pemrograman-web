<?php  

include 'functions.php';
$pendapatan = mysqli_query($conn, "SELECT id_kondektur, SUM(jumlah_km) AS total_km FROM trans_upn GROUP BY id_kondektur ORDER BY id_kondektur ASC");

if(isset($_POST['filter'])) {
  $bulan = $_POST['bulan'];
  $pendapatan = mysqli_query($conn, "SELECT id_kondektur, SUM(jumlah_km) AS total_km FROM trans_upn WHERE MONTH(tanggal) = '$bulan' GROUP BY id_kondektur ORDER BY id_kondektur ASC");
}

?>


<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
      <title>TransUPN</title>
    <meta name="description" content="" />

    <?php include '../include/link.php' ?>
    <style type="text/css">
      table th, td {
        text-align: center;
      }
      table th {
        font-weight: bold;
      }
    </style>
    
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        
        <!-- SIDEBAR -->
        <?php include '../include/sidebar.php'; ?>

        <!-- Layout container -->
        <div class="layout-page">
          
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
            

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header bg-primary text-white d-flex justify-content-between">Data Pendapatan Kondektur
                <span class="px-2">
                    <form action="" method="POST">
                        <select name="bulan" class="form-control">
                          <option style="display:none">:: Pilih Bulan :: </option>
                          <option value="1">Januari</option>
                          <option value="2">Februari</option>
                          <option value="3">Maret</option>
                          <option value="4">April</option>
                          <option value="5">Mei</option>
                          <option value="6">Juni</option>
                          <option value="7">Juli</option>
                          <option value="8">Agustus</option>
                          <option value="9">September</option>
                          <option value="10">Oktober</option>
                          <option value="11">November</option>
                          <option value="12">Desember</option>
                        </select>
                    <button type="submit" name="filter" class="btn btn-warning text-white w-100">Filter</button>
                    <a href="" class="btn btn-secondary text-white w-100">Refresh</a>

                    </form>
                  </span>
                </h5>
                <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
                  <table class="table table-hover table-responsive">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>ID kondektur</th>
                        <th>Nama kondektur</th>
                        <th>Jumlah KM</th>
                        <th>Pendapatan</th>
                        <th>Detail</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php $no = 1; ?>
                      <?php foreach($pendapatan as $td) : ?>
                        <?php 
                          $id_kondektur = $td['id_kondektur'];
                          $kondektur = query("SELECT * FROM kondektur WHERE id_kondektur = $id_kondektur")[0];
                        ?>
                        <tr>
                          <td><?= $no; $no++  ?></td>
                          <td><?= $td['id_kondektur']; ?></td>
                          <td><?= $kondektur['nama']; ?></td>
                          <td><?= $td['total_km']; ?></td>
                          <td>Rp <?= number_format($td['total_km'] * 1500, 0); ?></td>
                          <td> <a href="detail_kondektur.php?id_kondektur=<?= $td['id_kondektur'];?>">Lihat</a></td>
                      <?php endforeach; ?>

                      </tbody>
                  </table>
                </div>
              </div>
              <!--/ Basic Bootstrap Table -->
              <hr class="mb-2" />
              
            </div>
            <!-- / Content -->

            
            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->

        
    </div>

    <?php include '../include/js.php'; ?>

  </body>
</html>
