<?php
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "transupn");

function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	};
	return $rows;
};

function tambah_bus($data){
	global $conn;

	$plat = mysqli_real_escape_string($conn, $data["plat"]);
	$status = mysqli_real_escape_string($conn, $data["status"]);

	mysqli_query($conn, "INSERT INTO bus VALUES(NULL, '$plat', '$status')");

	return mysqli_affected_rows($conn);
}


function edit_bus($data){
	global $conn;

	$id_bus = $data['id_bus'];
	
	$plat = mysqli_real_escape_string($conn, $data["plat"]);
	$status = mysqli_real_escape_string($conn, $data["status"]);

	$query = "UPDATE bus SET 
		plat = '$plat',
		status = '$status'
		WHERE id_bus = $id_bus
		"; 
		
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

function hapus_bus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM bus WHERE id_bus = $id");

	return mysqli_affected_rows($conn);
}


function tambah_driver($data){
	global $conn;

	$nama = mysqli_real_escape_string($conn, $data["nama"]);
	$no_sim = mysqli_real_escape_string($conn, $data["no_sim"]);
	$alamat = mysqli_real_escape_string($conn, $data["alamat"]);

	mysqli_query($conn, "INSERT INTO driver VALUES(NULL, '$nama', '$no_sim', '$alamat')");

	return mysqli_affected_rows($conn);
}


function edit_driver($data){
	global $conn;

	$id_driver = $data['id_driver'];
	
	$nama = mysqli_real_escape_string($conn, $data["nama"]);
	$no_sim = mysqli_real_escape_string($conn, $data["no_sim"]);
	$alamat = mysqli_real_escape_string($conn, $data["alamat"]);

	$query = "UPDATE driver SET 
		nama = '$nama',
		no_sim = '$no_sim',
		alamat = '$alamat'
		WHERE id_driver = $id_driver
		"; 
		
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

function hapus_driver($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM driver WHERE id_driver = $id");

	return mysqli_affected_rows($conn);
}



function tambah_kondektur($data){
	global $conn;

	$nama = mysqli_real_escape_string($conn, $data["nama"]);

	mysqli_query($conn, "INSERT INTO kondektur VALUES(NULL, '$nama')");

	return mysqli_affected_rows($conn);
}


function edit_kondektur($data){
	global $conn;

	$id_kondektur = $data['id_kondektur'];
	
	$nama = mysqli_real_escape_string($conn, $data["nama"]);

	$query = "UPDATE kondektur SET 
		nama = '$nama'
		WHERE id_kondektur = $id_kondektur
		"; 
		
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

function hapus_kondektur($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM kondektur WHERE id_kondektur = $id");

	return mysqli_affected_rows($conn);
}


function tambah_trans_upn($data){
	global $conn;

	$id_kondektur = mysqli_real_escape_string($conn, $data["id_kondektur"]);
	$id_bus = mysqli_real_escape_string($conn, $data["id_bus"]);
	$id_driver = mysqli_real_escape_string($conn, $data["id_driver"]);
	$jumlah_km = mysqli_real_escape_string($conn, $data["jumlah_km"]);
	$tanggal = mysqli_real_escape_string($conn, $data["tanggal"]);

	mysqli_query($conn, "INSERT INTO trans_upn VALUES(NULL, '$id_kondektur', '$id_bus', '$id_driver', '$jumlah_km', '$tanggal')");

	return mysqli_affected_rows($conn);
}


function edit_trans_upn($data){
	global $conn;

	$id_trans_upn = $data['id_trans_upn'];
	
	$id_kondektur = mysqli_real_escape_string($conn, $data["id_kondektur"]);
	$id_bus = mysqli_real_escape_string($conn, $data["id_bus"]);
	$id_driver = mysqli_real_escape_string($conn, $data["id_driver"]);
	$jumlah_km = mysqli_real_escape_string($conn, $data["jumlah_km"]);
	$tanggal = mysqli_real_escape_string($conn, $data["tanggal"]);

	$query = "UPDATE trans_upn SET 
		id_kondektur = '$id_kondektur',
		id_bus = '$id_bus',
		id_driver = '$id_driver',
		jumlah_km = '$jumlah_km',
		tanggal = '$tanggal'
		WHERE id_trans_upn = $id_trans_upn
		"; 
		
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

function hapus_trans_upn($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM trans_upn WHERE id_trans_upn = $id");

	return mysqli_affected_rows($conn);
}


?>
