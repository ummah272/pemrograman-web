<?php  
include 'functions.php';
$kondektur = mysqli_query($conn, "SELECT * FROM kondektur");
?>

<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
      <title>TransUPN</title>
    <meta name="description" content="" />

    <?php include '../include/link.php' ?>
    <style type="text/css">
      table th, td {
        text-align: center;
      }
      table th {
        font-weight: bold;
      }
    </style>
    
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        
        <!-- SIDEBAR -->
        <?php include '../include/sidebar.php'; ?>

        <!-- Layout container -->
        <div class="layout-page">
          
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
            

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header bg-primary text-white">Data kondektur
                  <span class="px-2">
                    <a href="tambah_kondektur.php" class="btn btn-warning text-white">Tambah Data</a>
                  </span>
                </h5>
                <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
                  <table class="table table-hover table-responsive">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Plat</th>
                        <th style="width: 200px">Aksi</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php $no = 1; ?>
                      <?php foreach($kondektur as $td) : ?>
                        <tr>
                          <td><?= $no; $no++  ?></td>
                          <td><?= $td['nama']; ?></td>
                        
                          <td style="display: block;">
                            <a class="btn btn-primary m-2" href="edit_kondektur.php?id_kondektur=<?= $td['id_kondektur']; ?>">
                              <i class="bx bx-edit-alt me-1 text-white"></i> 
                            </a>
                            <a class="btn btn-danger" 
                              href="hapus_kondektur.php?id_kondektur=<?= $td['id_kondektur']; ?>" 
                              onclick="return confirm('Yakin ingin menghapus ?')">
                              <i class="bx bx-trash me-1 text-white"></i> 
                            </a>
                          </td>

                        </tr>
                      <?php endforeach; ?>

                      </tbody>
                  </table>
                </div>
              </div>
              <!--/ Basic Bootstrap Table -->
              <hr class="mb-2" />
              
            </div>
            <!-- / Content -->

            
            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->

        
    </div>

    <?php include '../include/js.php'; ?>

  </body>
</html>
