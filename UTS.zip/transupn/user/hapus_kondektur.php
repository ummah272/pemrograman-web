4<?php
require 'functions.php';
$id = $_GET["id_kondektur"];
if (hapus_kondektur($id) > 0 ) {
	echo "
		<script>
			alert('Data berhasil dihapus!');
			document.location.href = 'data_kondektur.php';
		</script>
	";
    } else {
	echo "
		<script>
			alert('Data gagal dihapus!');
		</script>
	";
	}
 ?>
