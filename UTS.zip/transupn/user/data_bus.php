<?php  
include 'functions.php';
$bus = mysqli_query($conn, "SELECT * FROM bus");

if(isset($_POST['filter'])) {
  $status = $_POST['status'];
  $bus = mysqli_query($conn, "SELECT * FROM bus WHERE status = $status");
}

?>

<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
      <title>TransUPN</title>
    <meta name="description" content="" />

    <?php include '../include/link.php' ?>
    <style type="text/css">
      table th, td {
        text-align: center;
      }
      table th {
        font-weight: bold;
      }
    </style>
    
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        
        <!-- SIDEBAR -->
        <?php include '../include/sidebar.php'; ?>

        <!-- Layout container -->
        <div class="layout-page">
          
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
            

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header bg-primary text-white">Data Bus
                    <a href="tambah_bus.php" class="btn btn-warning text-white">Tambah Data</a> <br><br>
                  <span class="px-2 d-flex justify-content-between">
                    <form action="" method="POST">
                        <select name="status" class="form-control">
                          <option style="display:none">:: Pilih Status :: </option>
                          <option value="0">0</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                        </select>
                        <br>
                    <button type="submit" name="filter" class="btn btn-warning text-white w-100">Filter</button>
                    <br><br>
                    <a href="" class="btn btn-secondary text-white w-100">Refresh</a>
                    <br>
                    </form>
                  </span>
                </h5>
                <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
                  <table class="table table-hover table-responsive">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Plat</th>
                        <th>Status</th>
                        <th>Jarak yang ditempuh</th>
                        <th style="width: 100px">Aksi</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php $no = 1; ?>
                      <?php foreach($bus as $td) : ?>

                      <?php 
                      $idb = $td['id_bus'];
                      $pdp = query("SELECT id_bus, SUM(jumlah_km) AS jmlh FROM trans_upn WHERE id_bus = $idb")[0];
                      ?>

                      <?php if($td['status'] == "1") : ?>
                        <tr>
                          <td class="bg-success fw-bold"><?= $no; $no++  ?></td>
                          <td class="bg-success fw-bold"><?= $td['plat']; ?></td>
                          <td class="bg-success fw-bold"><?= $td['status']; ?></td>
                          <td class="bg-success fw-bold"><?= $pdp['jmlh']; ?> km.</td>
                      <?php elseif($td['status'] == "2") : ?>
                        <tr>
                          <td class="bg-warning fw-bold"><?= $no; $no++  ?></td>
                          <td class="bg-warning fw-bold"><?= $td['plat']; ?></td>
                          <td class="bg-warning fw-bold"><?= $td['status']; ?></td>
                          <td class="bg-success fw-bold"><?= $pdp['jmlh']; ?> km.</td>
                      <?php elseif($td['status'] == "0") : ?>
                        <tr>
                          <td class="bg-danger fw-bold"><?= $no; $no++  ?></td>
                          <td class="bg-danger fw-bold"><?= $td['plat']; ?></td>
                          <td class="bg-danger fw-bold"><?= $td['status']; ?></td>
                          <td class="bg-success fw-bold"><?= $pdp['jmlh']; ?> km.</td>
                      <?php endif;?>
                        
                          <td style="display: block;">
                            <a class="btn btn-primary m-2" href="edit_bus.php?id_bus=<?= $td['id_bus']; ?>">
                              <i class="bx bx-edit-alt me-1 text-white"></i> 
                            </a>
                            <a class="btn btn-danger" 
                              href="hapus_bus.php?id_bus=<?= $td['id_bus']; ?>" 
                              onclick="return confirm('Yakin ingin menghapus ?')">
                              <i class="bx bx-trash me-1 text-white"></i> 
                            </a>
                          </td>

                        </tr>
                      <?php endforeach; ?>

                      </tbody>
                  </table>
                </div>
              </div>
              <!--/ Basic Bootstrap Table -->
              <hr class="mb-2" />
              
            </div>
            <!-- / Content -->

            
            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->

        
    </div>

    <?php include '../include/js.php'; ?>

  </body>
</html>
