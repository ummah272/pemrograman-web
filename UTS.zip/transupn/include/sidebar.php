  <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme pt-4">

    <h3 class="text-center text-dark fw-bold text-primary">TRANSUPN</h3>

    <ul class="menu-inner py-1">

      <!-- MENU -->
      <li class="menu-item mb-2">
        <a href="index.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-home"></i>
          <div data-i18n="Basic">Beranda</div>
        </a>
      </li>

      <!-- MENU -->
      <li class="menu-item mb-2">
        <a href="data_bus.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-data"></i>
          <div data-i18n="Basic">Bus</div>
        </a>
      </li>

      <li class="menu-item mb-2">
        <a href="data_driver.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-data"></i>
          <div data-i18n="Basic">Driver</div>
        </a>
      </li>

      <li class="menu-item mb-2">
        <a href="data_kondektur.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-data"></i>
          <div data-i18n="Basic">Kondektur</div>
        </a>
      </li>

      <li class="menu-item mb-2">
        <a href="data_trans_upn.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-data"></i>
          <div data-i18n="Basic">Trans UPN</div>
        </a>
      </li>

      <li class="menu-item mb-2">
        <a href="data_pendapatan_driver.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-money"></i>
          <div data-i18n="Basic">Pendapatan Driver</div>
        </a>
      </li>

      <li class="menu-item mb-2">
        <a href="data_pendapatan_kondektur.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-money"></i>
          <div data-i18n="Basic">Pendapatan Kondektur</div>
        </a>
      </li>



      <!-- <li class="menu-item mb-2">
        <a href="data_kriteria.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-pen"></i>
          <div data-i18n="Basic">Data Kriteria</div>
        </a>
      </li>

      <li class="menu-item mb-2">
        <a href="normalisasi.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-face"></i>
          <div data-i18n="Basic">Normalisasi</div>
        </a>
      </li>

      <li class="menu-item mb-2">
        <a href="perankingan.php" class="menu-link">
          <i class="menu-icon tf-icons bx bx-trophy"></i>
          <div data-i18n="Basic">Perankingan</div>
        </a>
      </li> -->

    </ul>
  </aside>